from pathlib import Path


def change(filename, old, new):
    path = Path(filename)
    text = path.read_text(encoding='utf-8')
    matches = text.count(old)
    if matches != 1:
        raise RuntimeError(f'{filename}: expected one matching section, found {matches}')
    path.write_text(text.replace(old, new, 1), encoding='utf-8')


change('planner.go', ' StartDate string `json:"start_date"`\n Warning string', ''' StartDate string `json:"start_date"`
 FirstWeekEnd string `json:"first_week_end"`
 FirstWeekTotals map[string]int `json:"first_week_totals"`
 FirstWeekMinutes map[string]int `json:"first_week_minutes"`
 FirstRotationDate string `json:"first_rotation_date,omitempty"`
 Warning string''')
change('planner.go', ' if start.Weekday()!=time.Monday{return p,fmt.Errorf("Startdato skal v\u00e6re en mandag")}\n', '')
change('planner.go', '   due:=start.AddDate(0,0,day).Format("2006-01-02")', '   due:=plannerScheduledDate(start,day,len(j.days)==1)')
change('planner.go', ' return p,nil\n}', ''' plannerDateDetails(&p,start,input.People)
 if input.StartDate<time.Now().In(a.loc).Format("2006-01-02"){p.Warning="Startdatoen ligger f\u00f8r i dag. Tidligere opgaver kan blive vist som forfaldne og udl\u00f8se p\u00e5mindelser."}
 return p,nil
}''')
change('planner.go', 'step:=int(target.Sub(anchor).Hours()/24)/7/weeks', 'step:=int(weekStart(target).Sub(weekStart(anchor)).Hours()/24)/7/weeks')
change('planner.go', 'map[string]any{"ok":true,"plan_id":planID,"created":len(steps)}', 'map[string]any{"ok":true,"plan_id":planID,"created":len(steps),"start_date":p.StartDate,"first_rotation_date":p.FirstRotationDate}')
change('main.go', '\t\tvisible, completionKey := taskOccurrence(due, target, r["repeat_rule"])', '''\t\tif !plannerTaskHasStarted(r["rotation_start"],day) {continue}
\t\tvisible, completionKey := taskOccurrence(due, target, r["repeat_rule"])''')
change('main.go', 'SELECT due_date,repeat_rule FROM tasks WHERE id=?', 'SELECT due_date,repeat_rule,rotation_start FROM tasks WHERE id=?')
change('main.go', '\tvisible, completionKey := taskOccurrence(due, selected, rows[0]["repeat_rule"])', '''\tif !plannerTaskHasStarted(rows[0]["rotation_start"],v.Day) {
\t\tapiError(w,400,"Opgaven er ikke startet p\u00e5 den valgte dato")
\t\treturn
\t}
\tvisible, completionKey := taskOccurrence(due, selected, rows[0]["repeat_rule"])''')

change('web/app.js', "field('Startdato (mandag)','<input name=\"start_date\" type=\"date\" required>')+", '''field('Hvorn\u00e5r skal planen starte?','<input id="plannerStartDate" name="start_date" type="date" aria-describedby="plannerStartHint" required>')+
      '<div class="field field-wide"><div class="ai-actions"><button type="button" class="minor" data-planner-start="today">I dag</button><button type="button" class="minor" data-planner-start="tomorrow">I morgen</button><button type="button" class="minor" data-planner-start="monday">N\u00e6ste mandag</button></div><p id="plannerStartHint" class="muted" role="status"></p></div>'+''')
change('web/app.js', "    var next=startWeek(new Date());if(next<localMidnight(new Date()))next=addDays(next,7);\n    $('plannerForm').elements.start_date.value=dayString(next);", '''    var dates=window.FamilyHubPlannerDates,startField=$('plannerForm').elements.start_date;
    startField.value=dates.today();
    function updateStartHint(){
      var value=startField.value;
      if(!value){$('plannerStartHint').textContent='V\u00e6lg en startdato.';return}
      $('plannerStartHint').textContent='Opgaver starter tidligst '+formatDate(new Date(value+'T12:00:00'),{weekday:'long',day:'numeric',month:'long',year:'numeric'})+'. Den f\u00f8rste uge kan v\u00e6re kortere. Opgavebytte sker om mandagen.'+(value<dates.today()?' Datoen ligger f\u00f8r i dag; opgaver kan blive forfaldne.':'');
    }
    document.querySelectorAll('[data-planner-start]').forEach(function(button){button.addEventListener('click',function(){
      startField.value=dates.shortcut(button.getAttribute('data-planner-start'),dates.today());
      startField.dispatchEvent(new Event('change',{bubbles:true}));
    })});
    startField.addEventListener('input',updateStartHint);
    startField.addEventListener('change',updateStartHint);
    updateStartHint();''')
change('web/app.js', "        var preview=await api('/api/planner/preview','POST',plannerDraft),root=$('plannerPreview');\n        root.appendChild(el('h3',null,'Forslag til opgaveplan'));", '''        var draft=plannerDraft;
        var preview=await api('/api/planner/preview','POST',draft),root=$('plannerPreview');
        if(plannerDraft!==draft||!root)return;
        root.appendChild(el('h3',null,'Forslag til opgaveplan'));
        root.appendChild(el('p',{'class':'planner-start-summary'},'Planen starter '+formatDate(new Date(preview.start_date+'T12:00:00'),{weekday:'long',day:'numeric',month:'long',year:'numeric'})+'. Ingen opgaver er aktive f\u00f8r denne dato.'));
        if(preview.first_rotation_date)root.appendChild(el('p',{'class':'muted'},'F\u00f8rste opgavebytte: '+formatDate(new Date(preview.first_rotation_date+'T12:00:00'),{weekday:'long',day:'numeric',month:'long',year:'numeric'})+'.'));
        if(preview.warning)root.appendChild(el('p',{'class':'warning'},preview.warning));
        if(preview.first_week_totals)root.appendChild(el('p',{'class':'muted'},'F\u00f8rste uge ('+preview.start_date+' til '+preview.first_week_end+'): '+people.map(function(id){return nameOf(id)+': '+preview.first_week_totals[id]+' point / '+preview.first_week_minutes[id]+' min.'}).join(' | ')));''')
change('web/app.js', "+' min. per uge'+(plannerDraft.rotate_weeks?", "+' min. i en fuld uge'+(draft.rotate_weeks?")
change('web/app.js', "api('/api/planner/advice','POST',plannerDraft)", "api('/api/planner/advice','POST',draft)")
change('web/app.js', "          if(!plannerDraft){saveStatus.textContent=", "          if(plannerDraft!==draft){saveStatus.textContent=")
change('web/app.js', "saved=await api('/api/planner/apply','POST',plannerDraft);", "saved=await api('/api/planner/apply','POST',draft);")
change('web/app.js', "          var startDate=plannerDraft.start_date;", "          var startDate=saved.start_date||draft.start_date;")
change('web/app.js', '''    $('plannerForm').addEventListener('change',function(){
      if(!plannerDraft)return;
      plannerDraft=null;
      $('plannerPreview').replaceChildren();
      $('formError').textContent='Indstillingerne er \u00e6ndret. Beregn planen igen for at godkende den.';
    });''', '''    function invalidatePlannerPreview(){
      if(!plannerDraft)return;
      plannerDraft=null;
      $('plannerPreview').replaceChildren();
      $('formError').textContent='Indstillingerne er \u00e6ndret. Beregn planen igen for at godkende den.';
    }
    $('plannerForm').addEventListener('input',invalidatePlannerPreview);
    $('plannerForm').addEventListener('change',invalidatePlannerPreview);''')
change('web/index.html','<link rel="icon" href="/icon.svg" type="image/svg+xml">', '''<link rel="icon" href="/favicon.ico?v=familyhub-1" sizes="32x32">
<link rel="icon" href="/icon.svg?v=familyhub-1" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png?v=familyhub-1" sizes="180x180">''')
change('web/index.html', '<script src="/app.js?v=local-llm-diagnostics-1" defer></script>', '''<script src="/planner-dates.js?v=start-date-1" defer></script>
<script src="/app.js?v=planner-start-date-1" defer></script>''')
# Moving an existing plan still shifts complete weeks. The original start
# weekday must be allowed and is preserved by the existing shift operation.
change('internal/mcpaccess/tools.go', 'if err != nil || d.Weekday() != time.Monday {', 'if err != nil {')
change('.github/workflows/ci.yml', '      - name: Check browser JavaScript syntax', '''      - name: Test planner date shortcuts
        run: node --test tests/planner_dates.test.js
      - name: Check browser JavaScript syntax''')
with Path('README.md').open('a',encoding='utf-8') as f:
    f.write('\n\n## Valgfri startdato i AI Opgaveplanl\u00e6gger\n\nV\u00e6lg **Hvorn\u00e5r skal planen starte?**; standarden er i dag i Europe/Copenhagen.\nGenveje: **I dag**, **I morgen**, **N\u00e6ste mandag**. Alle ugedage kan v\u00e6lges.\nOpgaver starter aldrig f\u00f8r den valgte dato. En start midt i ugen giver en kortere\nf\u00f8rste uge, som vises separat i forh\u00e5ndsvisningen. Ugentligt opgavebytte f\u00f8lger\nfortsat kalenderuger (mandag); datoen for f\u00f8rste bytte vises inden godkendelse.\n\nEksisterende opgaver \u00e6ndres ikke. FamilieHubs hus-ikon bruges ogs\u00e5 som\nfavicon (SVG + ICO) og Apple touch-ikon. Se docs/PLANNER-START.md.\n')
